package vn2.model.entities;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import utils.MesOutils;
import vn2.model.exceptions.AccessoireException;
import vn2.model.references.TypeAccessoire;

@ToString(of= {"letype","possede"})
public class Accessoire implements Possedable{
    @Getter
	private TypeAccessoire leType;
    @Setter
    private boolean possede;

    //SETTER
	public void setLeType(TypeAccessoire leType) throws AccessoireException {
		try {
			MesOutils.controler(leType);
		} catch (Exception e) {
			throw new AccessoireException(e.getMessage());
		}
		this.leType = leType;
	}

    //Constructeur
	public Accessoire(TypeAccessoire leType, boolean possede) throws AccessoireException {
		setLeType(leType);
		setPossede(possede);
	}

		@Override
	public TypeAccessoire gTypeAccessoire() {
		return this.leType;
	}

	
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append(String.format("%8s : %s", leType.name(),(possede?"OUI":"NON")));
		
		return builder.toString();
	}

	@Override
	public boolean isPossede() {
		return this.possede;
	}
	
	
}
