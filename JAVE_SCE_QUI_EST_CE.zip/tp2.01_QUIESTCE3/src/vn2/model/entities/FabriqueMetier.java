package vn2.model.entities;

import java.util.List;

import vn2.model.exceptions.AbstractJoueurException;
import vn2.model.exceptions.AccessoireException;
import vn2.model.exceptions.PartieException;
import vn2.model.exceptions.PersonnageException;
import vn2.model.exceptions.QuestionException;
import vn2.model.references.TypeAccessoire;
import vn2.model.references.TypeQuestion;

public final class FabriqueMetier {

	private FabriqueMetier() {}
	
	
	public static Possedable creerAccessoire(TypeAccessoire leType,boolean possede) throws AccessoireException {
		return new Accessoire(leType, possede);
	}

	public static Personnage creerPersonnage(String nom,char sexe, String ch, String ye, List<Possedable> ls) throws PersonnageException {
			return new Personnage(nom,sexe,ch,ye,ls);
	}
	
	public static Questionnable creerQuestionCarac(TypeQuestion tq,String val) throws QuestionException  {
		Questionnable q =  new Question(tq, val);	
		
		return q;
	}
	public static Questionnable creerQuestionAcc(TypeAccessoire ta) throws QuestionException  {
		Questionnable q = new Question(ta);
		
		return q;
	}
	
	public static QuiEstCeJouable creerJoueurIA() throws AbstractJoueurException {
		return new JoueurIA();
	}
	public static QuiEstCeJouable creerJoueurHumain(String nom) throws AbstractJoueurException {
		return new JoueurHumain(nom);
	}
	public static Partie creerPartie(QuiEstCeJouable jIA) throws PartieException {
		return new Partie(jIA);
	}
}
