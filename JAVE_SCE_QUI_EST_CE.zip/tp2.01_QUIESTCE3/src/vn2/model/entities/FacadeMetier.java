package vn2.model.entities;

import java.util.ArrayList;
import java.util.List;

import vn2.model.dao.DaoPersonnage;
import vn2.model.dao.exceptions.DaoException;
import vn2.model.exceptions.AbstractJoueurException;
import vn2.model.exceptions.PartieException;

public class FacadeMetier {

	private DaoPersonnage persistance;
	private Partie laPartie;
	
	
	public FacadeMetier(String cheminFichier) throws DaoException {
		persistance = new DaoPersonnage(cheminFichier);
	}

	public List<Identifiable> listerTous() {
		return persistance.readAll();
	}

	public void creerPartie() throws AbstractJoueurException, PartieException, DaoException {
		QuiEstCeJouable jIA = FabriqueMetier.creerJoueurIA();
		laPartie = FabriqueMetier.creerPartie(jIA);
		
	}


	public void ajouterJoueurHumain(String nom) throws AbstractJoueurException, PartieException {
		QuiEstCeJouable joueurH= FabriqueMetier.creerJoueurHumain(nom);
		laPartie.setJh(joueurH);
		
	}

	public List<Identifiable> copyListe() throws CloneNotSupportedException {
		//1 recuperer liste non modifiable
		List<Identifiable> liste = persistance.readAll();
		List<Identifiable> listeW = new ArrayList<Identifiable>();
		
		//2 parcours de la l iste non modifiable
		//  et recopie des �l�ments dans la liste de W
		for (Identifiable ident : liste) {
			Identifiable ident2 = ident.clone();
			listeW.add(ident2);
		}
		return listeW;
	}


	public Partie getLaPartie() {
		
		return laPartie;
	}


	public String getNomATrouver() throws PartieException {
		return laPartie.getjIA().getPerso().getNom();
		
	}

	public boolean poserquestion(Questionnable laQuestion) {
		return laPartie.getjIA().repondre(laQuestion);
	}

	public void tirerPerso() throws AbstractJoueurException, DaoException {
		int idx =(int)(Math.random()*persistance.readAll().size());
		laPartie.getjIA().setPerso(persistance.getAt(idx));
		System.out.println("TIRAGE = "+persistance.getAt(idx));
	}
}
