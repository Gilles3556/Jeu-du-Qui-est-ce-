package vn2.model.entities;

import java.util.List;

import vn2.model.exceptions.AbstractJoueurException;
import vn2.model.exceptions.PartieException;
import vn2.model.references.C;
import vn2.view.Cview;

public class Partie {
	private QuiEstCeJouable jIA;
	private QuiEstCeJouable jh;
	
	public QuiEstCeJouable getjIA() {
		return jIA;
	}
	private void setjIA(QuiEstCeJouable jIA) throws PartieException {
		if (jIA==null){
			throw new PartieException(C.MSG_ERR_JOUEUR_IA_VAUT_NULL);
		}
//		if(!jIA.getNom().contentEquals(C.NOM_IA_DFLT)) {
//			throw new PartieException(C.MSG_ERR_JOUEUR_IA_INCORRECT);
//		}
		this.jIA = jIA;
	}
	public QuiEstCeJouable getJh() {
		return jh;
	}
	public void setJh(QuiEstCeJouable jh) throws PartieException {
		if (jh==null){
			throw new PartieException(C.MSG_ERR_JOUEUR_H_VAUT_NULL);
		}
//		if(jh.getNom().contentEquals(C.NOM_IA_DFLT)) {
//			throw new PartieException(C.MSG_ERR_JOUEUR_H_INCORRECT);
//		}
		this.jh = jh;
	}
	/**
	 * Constructeur complet.
	 * @param jIA AbstractJoueur: le joueur IA
	 * @param jh  AbstractJoueur: le joueur humain
	 * @throws PartieException
	 */
	public Partie(QuiEstCeJouable jIA) throws PartieException {
		setjIA(jIA);
	}
	
	public void demarrer(List<Identifiable> liste) throws AbstractJoueurException {
		initialiser(liste);
		lancer();
	}
	private void initialiser(List<Identifiable> liste) throws AbstractJoueurException {
		//tirer un personnage au hasard
		int nbPerso = (int)(Math.random()*liste.size());
		
		//l'affecter un Perso au jouSeurIA
		jIA.setPerso(liste.get(nbPerso));
	}

	private void lancer() {
		//
	}
	public  Identifiable getPerso() throws PartieException {
		if (jIA==null) {
			throw new PartieException(C.MSG_ERR_PERSONNAGE_VAUT_NULL);
		}
		return jIA.getPerso();
	}
}
