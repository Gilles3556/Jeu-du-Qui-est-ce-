package vn2.model.entities;

import vn2.model.exceptions.AbstractJoueurException;
import vn2.model.references.C;
import vn2.model.references.TypeAccessoire;

public interface QuiEstCeJouable {

	public default boolean questionner(AbstractJoueur aj, Questionnable qcu) {
		throw new UnsupportedOperationException(C.MSG_ERR_OPERATION_NON_SUPPORTEE);
	}
	
	public default boolean repondre(Questionnable qcu){
		throw new UnsupportedOperationException(C.MSG_ERR_OPERATION_NON_SUPPORTEE);
	}
	
	
	public default void setPerso(Identifiable personnage) throws AbstractJoueurException{
		throw new UnsupportedOperationException(C.MSG_ERR_OPERATION_NON_SUPPORTEE);
	}
	
	public Identifiable getPerso();
	
}
