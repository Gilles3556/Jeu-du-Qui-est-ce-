package vn2.model.entities;

import vn2.model.exceptions.AbstractJoueurException;
import vn2.model.references.C;

public class JoueurHumain extends AbstractJoueur {

	public JoueurHumain(String nom) throws AbstractJoueurException {
		super(nom);
	}

	@Override
	public boolean questionner(AbstractJoueur aj, Questionnable qcu) {
		return aj.repondre(qcu);
	}
}
