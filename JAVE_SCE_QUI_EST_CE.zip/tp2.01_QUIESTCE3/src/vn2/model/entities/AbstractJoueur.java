package vn2.model.entities;

import vn2.model.exceptions.AbstractJoueurException;
import vn2.model.references.C;

public abstract class AbstractJoueur implements QuiEstCeJouable{
  private String nom;
  protected Identifiable perso;
  
  public AbstractJoueur(String nom) throws AbstractJoueurException {
	  setNom(nom);
  }

public Identifiable getPerso() {
	return perso;
}
@Override
public void setPerso(Identifiable perso) throws AbstractJoueurException {
	if(perso==null) {
		throw new AbstractJoueurException(C.MSG_ERR_PERSONNAGE_VAUT_NULL);
	}
//	Pour autoriser la relance d'une partie depuis MENUP: CHOIX3
//	if (this.perso!=null) {
//		throw new AbstractJoueurException(C.MSG_ERR_PERSONNAGE_DEJA_EXISTANT);	
//	}
	this.perso = perso;
}

public String getNom() {
	return nom;
}

private void setNom(String n) throws AbstractJoueurException {
	if(n==null) {
		throw new AbstractJoueurException(C.MSG_ERR_NOM_VAUT_NULL);
	}
	this.nom = n;
}




}
