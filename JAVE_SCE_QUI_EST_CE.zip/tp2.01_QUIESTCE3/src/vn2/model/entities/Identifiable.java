package vn2.model.entities;

import vn2.model.references.C;
import vn2.model.references.TypeAccessoire;

public interface Identifiable {
	
	public String getNom();
	public boolean getValeurAccessoire(TypeAccessoire unAccessoire);
	
	public char getSexe();
	
	public String getCheveux();
	
	public String getYeux();
	
	
	public default Identifiable clone() throws CloneNotSupportedException {
		throw new CloneNotSupportedException(C.MSG_ERR_OPERATION_NON_SUPPORTEE);
	}
}
