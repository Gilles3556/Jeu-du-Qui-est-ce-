package vn2.model.entities;

import vn2.model.exceptions.AbstractJoueurException;
import vn2.model.references.C;
import vn2.model.references.TypeAccessoire;

public class JoueurIA extends AbstractJoueur {

	public JoueurIA() throws AbstractJoueurException {
		super(C.NOM_IA_DFLT);
	}

	@Override
	public boolean repondre(Questionnable qcu) {
		boolean reponse = false;
		Identifiable pers = getPerso();
		
		if(qcu.getUnAccessoire()!=null) {
			//question sur un accessoire: LUN, BOUCLE, MOUS, BARB, CIGARE
		    reponse = pers.getValeurAccessoire(qcu.getUnAccessoire());
		}else{
			//question sur une carac: S,CH,YE
			switch(qcu.getLeType()) {
			case SEXE:
				reponse = (pers.getSexe()==qcu.getValeur().charAt(0));
				break;
			case CHEVEUX:
				reponse = (pers.getCheveux().contentEquals(qcu.getValeur()));
				break;
			case YEUX:
				reponse = (pers.getCheveux().contentEquals(qcu.getValeur()));
				break;
			}
		}
		
		return reponse;
	}




}
