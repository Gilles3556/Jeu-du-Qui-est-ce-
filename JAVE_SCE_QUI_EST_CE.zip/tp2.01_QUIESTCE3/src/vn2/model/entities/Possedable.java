package vn2.model.entities;

import vn2.model.references.TypeAccessoire;

public interface Possedable {
	 
	 public TypeAccessoire gTypeAccessoire();
	 public boolean isPossede();
	 
	 public String toString();
	 

}
