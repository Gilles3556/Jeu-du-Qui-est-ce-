package vn2.model.entities;

import vn2.model.references.TypeAccessoire;
import vn2.model.references.TypeQuestion;

public interface Questionnable {

	public TypeQuestion getLeType();
	public TypeAccessoire getUnAccessoire();
	public String getValeur();
}
