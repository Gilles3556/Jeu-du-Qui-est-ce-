package vn2.model.entities;

import vn2.model.exceptions.QuestionException;
import vn2.model.references.C;
import vn2.model.references.TypeAccessoire;
import vn2.model.references.TypeQuestion;

public class Question implements Questionnable {
    
	private TypeQuestion leType;
	private String valeur;
	private TypeAccessoire unAccessoire;
	/**
	 * Constructeur d'un question sur carac de base(S,CH,YE) 
	 * @param t Typequestion: le type de la question
	 * @param val String: valeur 
	 * @throws QuestionException
	 */
	public Question(TypeQuestion t ,String val) throws QuestionException {
		setLeType(t);
		setValeur(val);
		unAccessoire =null;
	}
	private void setValeur(String val) throws QuestionException {
		if(val==null) {
			throw new QuestionException(C.MSG_ERR_VALEUR_VAUT_NULL);
		}
		this.valeur = val;
	}
	
	public String getValeur() {
		return valeur;
	}
	/**
	 * Constructeur d'une question sur un accessoire( LUNETTE,BOUCLE, MOUSTACHE, BARBE, CIGARE).
	 * @param ta TypeAccessoire: le type d'accessoire
	 * @throws QuestionException
	 */
	public Question(TypeAccessoire ta) throws QuestionException {
		this.valeur = null;
		this.leType = TypeQuestion.ACCESSOIRE;
		setUnAccessoire(ta);
	}
	

	private void setUnAccessoire(TypeAccessoire ta) throws QuestionException {
		if(ta == null) {
			throw new QuestionException(C.MSG_ERR_TYPE_ACCESSOIRE_VAUT_NULL);
		}
		this.unAccessoire=ta;
	}
	private void setLeType(TypeQuestion t) throws QuestionException {
		if(t==null) {
			throw new QuestionException(C.MSG_ERR_TYPE_QUESTION_VAUT_NULL);
		}
	    this.leType = t;	
	}
	public TypeQuestion getLeType() {
		return leType;
	}
	public TypeAccessoire getUnAccessoire() {
		return unAccessoire;
	}
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Question [");
		if(leType!=null) {
			builder.append(leType);
			builder.append(", valeur=");
			builder.append(valeur);
		}
		if( unAccessoire!=null) {
			builder.append(", unAccessoire=");
			builder.append(unAccessoire);
		}
		builder.append("]");
		return builder.toString();
	}
	
	

}
