package vn2.model.entities;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.ToString;
import utils.MesOutils;
import vn2.model.exceptions.PersonnageException;
import vn2.model.references.TypeAccessoire;

@AllArgsConstructor
@ToString(of= {"nom","sexe","cheveux","yeux","lesAccessoires"})
@EqualsAndHashCode(of= {"nom"})
public class Personnage implements Identifiable{
    @Getter
	private String nom;
    @Getter
	private char sexe;
    @Getter
	private String cheveux;
    @Getter
	private String yeux;
	@Getter
    private List<Possedable> lesAccessoires;
	
	public void setNom(String nom) throws PersonnageException{
		try {
			MesOutils.controlerChaine(nom);
		} catch (Exception e) {
			throw new PersonnageException(e.getMessage());
		}
		this.nom = nom;
	}
	public void setSexe(char sexe) throws PersonnageException {
		if (sexe!='M' && sexe !='F') {
			throw new PersonnageException("ERR: cract�re incorrect pour le sexe ['M'/'F']");
		}
		this.sexe = sexe;
	}
	public void setCheveux(String cheveux) throws PersonnageException {
		try {
			MesOutils.controlerChaine(cheveux);
		} catch (Exception e) {
			throw new PersonnageException(e.getMessage());
		}
		this.cheveux = cheveux;
	}
	public void setYeux(String yeux) throws PersonnageException {
		try {
			MesOutils.controlerChaine(yeux);
		} catch (Exception e) {
			throw new PersonnageException(e.getMessage());
		}
		this.yeux = yeux;
	}
	public void setLesAccessoires(List<Possedable> lesAccessoires) {
		this.lesAccessoires = lesAccessoires;
	}
    
	public boolean getValeurAccessoire(TypeAccessoire tacc) {
		boolean valeur = false;
		
		int idx=-1;
		switch(tacc) {
		case LUNETTE:
			idx = 0;
		   break;
		case BOUCLE_DOREILLE:
			idx = 1;
		   break;
		case MOUSTACHE:
			idx = 2;
		   break;
		case BARBE:
			idx = 3;
		   break;
		case CIGARE:
			idx = 4;
		   break;			   
		}
		valeur = lesAccessoires.get(idx).isPossede();
		
		return valeur;
	}
	
   @Override
   public Identifiable clone() throws CloneNotSupportedException {
	   Identifiable newIdent=null;
		try {
			newIdent = FabriqueMetier.creerPersonnage(this.nom,
						                              this.sexe, 
						                              this.cheveux, 
						                              this.yeux,
						                              this.getLesAccessoires());
		} catch (PersonnageException e) {
			throw new  CloneNotSupportedException(e.getMessage()); 
		}
	   return newIdent;
   }
}
