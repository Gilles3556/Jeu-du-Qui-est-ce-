package vn2.model.exceptions;

public class AbstractJoueurException extends Exception {

	public AbstractJoueurException(String message) {
		super(message);
	}

	public AbstractJoueurException(Throwable cause) {
		super(cause);
	}

	public AbstractJoueurException(String message, Throwable cause) {
		super(message, cause);
	}


}
