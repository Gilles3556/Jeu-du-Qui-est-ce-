package vn2.model.exceptions;

public class PartieException extends Exception {

	public PartieException(String message) {
		super(message);
	}

	public PartieException(Throwable cause) {
		super(cause);
	}

	public PartieException(String message, Throwable cause) {
		super(message, cause);
	}

}
