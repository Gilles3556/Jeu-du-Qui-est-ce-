package vn2.model.exceptions;

public class PersonnageException extends Exception {

	public PersonnageException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public PersonnageException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public PersonnageException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	
}
