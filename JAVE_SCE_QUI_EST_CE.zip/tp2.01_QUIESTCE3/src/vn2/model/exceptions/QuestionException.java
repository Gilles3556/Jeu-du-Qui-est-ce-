package vn2.model.exceptions;

public class QuestionException extends Exception {
	public QuestionException(String message) {
		super(message);
	}

	public QuestionException(Throwable cause) {
		super(cause);
	}

	public QuestionException(String message, Throwable cause) {
		super(message, cause);
	}

}
