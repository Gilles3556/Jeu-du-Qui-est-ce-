package vn2.model.exceptions;

public class AccessoireException extends Exception {

	public AccessoireException(String message) {
		super(message);
	}

	public AccessoireException(Throwable cause) {
		super(cause);
	}

	public AccessoireException(String message, Throwable cause) {
		super(message, cause);
	}

	
}
