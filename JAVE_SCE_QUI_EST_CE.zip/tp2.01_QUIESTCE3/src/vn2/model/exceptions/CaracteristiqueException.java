package vn2.model.exceptions;

public class CaracteristiqueException extends Exception {

	
	public CaracteristiqueException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public CaracteristiqueException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public CaracteristiqueException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	

}
