package vn2.model.references;

public enum TypeQuestion {
SEXE, CHEVEUX, YEUX, ACCESSOIRE;
}
