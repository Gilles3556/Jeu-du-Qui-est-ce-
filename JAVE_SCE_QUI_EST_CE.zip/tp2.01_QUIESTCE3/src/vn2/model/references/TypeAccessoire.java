package vn2.model.references;

public enum TypeAccessoire {
LUNETTE,
BOUCLE_DOREILLE,
MOUSTACHE,
BARBE,
CIGARE
}
