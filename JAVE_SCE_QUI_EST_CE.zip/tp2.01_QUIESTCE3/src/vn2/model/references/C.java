package vn2.model.references;

public class C {

	public static final String MSG_ERR_NOM_VAUT_NULL = "ERR: le nom vaut null !";
	public static final String MSG_ERR_TYPE_QUESTION_VAUT_NULL = "ERR: le type de question vaut null!";
	public static final String MSG_ERR_TYPE_ACCESSOIRE_VAUT_NULL = "ERR: le type d'accessoire vaut null";
	public static final String NOM_IA_DFLT = "JoueurIA";
	public static final String MSG_ERR_OPERATION_NON_SUPPORTEE = "ERR: op�ration non support�e !";
	public static final String MSG_ERR_PERSONNAGE_VAUT_NULL = "ERR: le personnage vaut null ";
	public static final String MSG_ERR_PERSONNAGE_DEJA_EXISTANT = "ERR: le personnage existe d�j�";
	public static final String MSG_ERR_VALEUR_VAUT_NULL = "ERR: la valeur vaut null";
	public static final String MSG_ERR_JOUEUR_IA_VAUT_NULL = "ERR: JOUEUR IA vaut null";
	public static final String MSG_ERR_JOUEUR_IA_INCORRECT = "ERR: joueur IA incorrect";
	public static final String MSG_ERR_JOUEUR_H_VAUT_NULL = "ERR: joueur H vaut null";
	public static final String MSG_ERR_JOUEUR_H_INCORRECT = "ERR:  joueur H incorrect";

}
