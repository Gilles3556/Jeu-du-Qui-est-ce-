package vn2.model.dao;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import vn2.model.dao.exceptions.DaoException;
import vn2.model.entities.Identifiable;

public abstract class AbstractDao<T,K> implements Dao<T, K> {

	protected ArrayList<T> liste;
	
	public AbstractDao() {
		liste = new ArrayList<T>();
	}

	@Override
	public void create(T t) throws DaoException {
		if(t==null) {
			throw new DaoException("ERR: objet vaut null");
		}
		if(this.exist(t)) {
			throw new DaoException("ERR: l'objet existe d�j�");
		}
		liste.add(t);
	}

	@Override
	public abstract T read(K k);

	@Override
	public void delete(T t) throws DaoException {
		if(t==null) {
			throw new DaoException("ERR: objet vaut null");
		}
		if(!this.exist(t)) {
			throw new DaoException("ERR: l'objet existe d�j�");
		}
		liste.remove(t);
		
	}

	@Override
	public void update(T t) throws DaoException {
		delete(t);
		create(t);
		
	}

	@Override
	public List<T> readAll() {
		return Collections.unmodifiableList(liste);
	}

	@Override
	public boolean exist(T t) throws DaoException {
		if(t==null) {
			throw new DaoException("ERR: objet vaut null");
		}
		if (liste.size()>0 && liste.contains(t)) {
			return true;
		}else {
			return false;
		}
	}

	public T getAt(int idx) throws DaoException {
		if(liste==null) {
			throw new DaoException("ERR.DAO: PBM liste vaut null");
		}
		if (liste.isEmpty()) {
			throw new DaoException("ERR.DAO: PBM la liste est vide");
		}
		if (idx>liste.size()) {
			throw new DaoException("ERR.DAO: indice hors de la liste");
		}
		return liste.get(idx);
	}
	
	@Override
	public abstract void initialiser() throws vn2.model.dao.exceptions.DaoException;

}
