package vn2.model.dao;

public final class CDao {

	private CDao() {	}

	public final static int IDX_NOM=0;
	public final static int IDX_SEXE=1;
	public final static int IDX_CHEVEUX=2;
	public final static int IDX_YEUX=3;
	public final static int IDX_LUNETTE=4;
	public final static int IDX_BOUCLE=5;
	public final static int IDX_MOUSTACHE=6;
	public final static int IDX_BARBE=7;
	public final static int IDX_CIGARE=8;
	
}
