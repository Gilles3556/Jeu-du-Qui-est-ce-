package vn2.model.dao;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import vn2.model.dao.exceptions.DaoException;
import vn2.model.entities.FabriqueMetier;
import vn2.model.entities.Identifiable;
import vn2.model.entities.Possedable;
import vn2.model.exceptions.AccessoireException;
import vn2.model.exceptions.PersonnageException;
import vn2.model.references.TypeAccessoire;

public class DaoPersonnage extends AbstractDao<Identifiable, String> {
    
	private String strProperties;
	
	public DaoPersonnage(String cheminFichier) throws DaoException {
        super(); 
		setStrProperties(cheminFichier);
        initialiser();
	}
	
	private void setStrProperties(String cheminFichier) throws DaoException {
		if(cheminFichier==null) {
			throw new DaoException("ERR: le chemin du fichier porperties vaut null");
		}
		cheminFichier = cheminFichier.trim();
		if(cheminFichier.isEmpty()){
			throw new DaoException("ERR: le nom du fichier porperties est vide !");  
		}
	    this.strProperties = cheminFichier;
		
	}

	@Override
	public Identifiable read(String k) {
		for(int i=0;i<liste.size();i++) {
			if(liste.get(i).getNom().equals(k)) {
				return liste.get(i); 
			}
		}
		return null;
	}

	@Override
	public void initialiser() throws DaoException {
		// chargement du fichier properties
		Properties props = new Properties();
		try {
			props.load(new FileInputStream(new File(strProperties)));
		
		//Parcours du fichier
		 for(int p=1;p<props.size();p++) {
		    	
			 String valeur = (String) props.get("pers"+p);
		    	valeur=valeur.substring(1).trim(); //enlever " au d�but et ESPACES ???
		    	valeur=valeur.substring(0,valeur.length()-1); //enlever la quote de fin
		    	String[] tab = valeur.split("-");
		    	
		        // cr�ation d'un objet Personnage
		    	String n = tab[CDao.IDX_NOM].trim();
		    	char sex = tab[CDao.IDX_SEXE].charAt(0);
		    	String ch = tab[CDao.IDX_CHEVEUX].trim();
		    	String ye = tab[CDao.IDX_YEUX].trim();

		    	// cr�ation des accessoires
		    	List<Possedable> lsAcc= new ArrayList<Possedable>();
		    	Possedable accLunette   = FabriqueMetier.creerAccessoire(TypeAccessoire.LUNETTE,tab[CDao.IDX_LUNETTE].contentEquals("1")?true:false);
		    	lsAcc.add(accLunette);
		    	Possedable accBoucle    = FabriqueMetier.creerAccessoire(TypeAccessoire.BOUCLE_DOREILLE,tab[CDao.IDX_BOUCLE].contentEquals("1")?true:false);
		    	lsAcc.add(accBoucle);
		    	Possedable accMoustache = FabriqueMetier.creerAccessoire(TypeAccessoire.MOUSTACHE,tab[CDao.IDX_MOUSTACHE].contentEquals("1")?true:false);
		    	lsAcc.add(accMoustache);
		    	Possedable accBarbe     = FabriqueMetier.creerAccessoire(TypeAccessoire.BARBE,tab[CDao.IDX_BARBE].contentEquals("1")?true:false);
		    	lsAcc.add(accBarbe);
		    	Possedable accCigare    = FabriqueMetier.creerAccessoire(TypeAccessoire.CIGARE,tab[CDao.IDX_CIGARE].contentEquals("1")?true:false);
		    	lsAcc.add(accCigare);
		    	//
		        super.create(FabriqueMetier.creerPersonnage(n, sex, ch, ye, lsAcc));
		 }
		} catch (IOException e) {
			throw new DaoException("ERR.DAO: pbm acc�s fichier .porperties");
		} catch (AccessoireException e) {
			throw new DaoException("ERR.DAO: pbm accessoire dans le contenu du fichier .porperties");		
		} catch (PersonnageException e) {
			throw new DaoException("ERR.DAO: pbm dans la cr�ation du Personnage");
		} catch (DaoException e) {
			throw new DaoException("ERR.DAO: pbm chargement fichier .properties");
		} 
		
	}

	

}
