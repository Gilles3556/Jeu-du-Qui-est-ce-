package vn2.presenter;

import java.util.List;

import utils.MesOutils;
import utils.OutilsChaine;
import vn2.model.dao.exceptions.DaoException;
import vn2.model.entities.FabriqueMetier;
import vn2.model.entities.FacadeMetier;
import vn2.model.entities.Identifiable;
import vn2.model.entities.Questionnable;
import vn2.model.exceptions.AbstractJoueurException;
import vn2.model.exceptions.PartieException;
import vn2.model.exceptions.QuestionException;
import vn2.model.references.TypeAccessoire;
import vn2.model.references.TypeQuestion;
import vn2.presenter.exceptions.PresenterException;
import vn2.view.Cview;
import vn2.view.FabriqueIhm;
import vn2.view.Ihm;
import vn2.view.exceptions.IhmException;

public class Presenter {

	private FacadeMetier metier;
	private Ihm vue;
	
	public Presenter(Ihm v, String cheminProperties) {
	   try {
		 metier = new FacadeMetier(cheminProperties);
	     setVue(v);
	   } catch (DaoException e) {
		   vue.afficherErreur(e.getMessage());
	   } catch (PresenterException e) {
		   e.printStackTrace();
	   }
	}

	private void setVue(Ihm v) throws PresenterException {
		if (v==null) {
			throw new PresenterException(Cview.MSG_ERR_IHM_VAUT_NULL);
		}
		this.vue = v;
	}

	public void executer() {
		//plus tard choix avec menu ICI
		
		//Lister tous
		//vue.afficherChaine(metier.listerTous().toString());
		int chx=-1;
		do {
			//Afficher MENUP
			vue.afficherChaine(FabriqueIhm.creerMenuPrincipal());
			//R�aliser la saisie
			try {
				chx = vue.saisirEntier(Cview.INVITE_CHOIX, Cview.CHOIX_QUITTER, Cview.TAB_MENU_PRINCIPAL.length);
			    
				traiterChoixMenuPrincipal(chx);
			} catch (IhmException | AbstractJoueurException | PartieException | CloneNotSupportedException | DaoException | QuestionException e) {
				vue.afficherErreur(e.getMessage());
			}
			
		}while(chx!=Cview.CHOIX_QUITTER);
	}
	/**
	 * M�thode charg�e de g�rer les traitements de chaque choix.
	 * @param chx int: le choix saisi
	 * @throws AbstractJoueurException 
	 * @throws PartieException 
	 * @throws CloneNotSupportedException 
	 * @throws DaoException 
	 * @throws QuestionException 
	 * @throws IhmException 
	 */
	private void traiterChoixMenuPrincipal(int chx) throws AbstractJoueurException, PartieException, CloneNotSupportedException, DaoException, QuestionException, IhmException {
		switch(chx) {
		case Cview.MENUP_CHX1_INIT:
			//MEP d'une partie??
			metier.creerPartie();

		    vue.afficherChaine(Cview.CHOIX1_OK);
			break;
		case Cview.MENUP_CHX2_INSC:
			vue.afficherChaine(Cview.TITRE_INSCRIPTION);
			//r�aliser la saisie du nom du joueur humain
			String nom = vue.saisirChaine("votre nom ?");
			metier.ajouterJoueurHumain(nom);
			
			vue.afficherChaine(Cview.CHOIX2_OK);
			break;
		case Cview.MENUP_CHX3_PARTIE:
			metier.tirerPerso();
			//affichage du SMENU
			lancerPartie(vue);
			break;
		
		case 4: 
			
			for (int i=0;i<metier.listerTous().size();i++) {
				Identifiable ident = metier.listerTous().get(i); 
				vue.afficherChaine(String.format("%n Perso n�%d %s",i, ident.getNom()));
				vue.afficherChaine(FabriqueIhm.constuireTete(ident));	
			}
			break;
		}

	}
	private void lancerPartie(Ihm vue) throws CloneNotSupportedException, QuestionException {
		//r�cuperer la liste des Personnages
		List<Identifiable> ls = metier.copyListe();
		
		int chx=-1;
		boolean finPartie = false;
		do {
			//Afficher la liste des personnages
			afficherLesPersonnages2(vue,ls);
			
			vue.afficherChaine(FabriqueIhm.creerSmenuPartie());
			try {
				chx = vue.saisirEntier(Cview.INVITE_CHOIX, Cview.CHOIX_QUITTER, Cview.TAB_SMENU_PARTIE.length);
				finPartie = traiterChoixSousMenuPartie(vue,chx,ls);
			
			} catch (IhmException | PartieException e) {
				vue.afficherErreur(e.getMessage());
			}
		
		}while (!finPartie && chx !=Cview.CHOIX_QUITTER);
		
	}
	/**
	 * M�thode charg�e d'afficher la liste des personnages.
	 * @param v Ihm: affichage et saisie
	 * @param ls List<Identifiable>: la liste
	 */
    private void afficherLesPersonnages(Ihm v, List<Identifiable> ls) {
    	//v0
     	//v.afficherChaine(ls.toString());
    	//V1
    	StringBuilder builder = new StringBuilder(Cview.TITRE_LISTE);
		builder.append(System.lineSeparator());
		for (int i=0; i<ls.size();i++) {
			Identifiable ident = ls.get(i);
			builder.append(String.format("-%2d %10s %c %7s %7s",
					     (i+1),
					     ident.getNom(),
					     ident.getSexe(),
					     ident.getCheveux(),
					     ident.getYeux()));
			
		    for (TypeAccessoire ta : TypeAccessoire.values()) {
				if (ident.getValeurAccessoire(ta)) {
		    		builder.append(" ! 1 ");
		    	}else {
		    		builder.append(" ! 0 ");
		    	}
			} 
		    builder.append(System.lineSeparator());
		}
		builder.append(System.lineSeparator());
		
    	v.afficherChaine(builder.toString());
    	//1 en tableau
    	//2 avec dessin
     	
   }
    private void afficherLesPersonnages2(Ihm v, List<Identifiable> ls) {
    	StringBuilder builder = new StringBuilder(Cview.TITRE_LISTE);
		builder.append(System.lineSeparator());
		String[][] tabTetes = new String[ls.size()][7];
		
		//construire le dessin des Personnages de la lite
		for (int i=0; i<ls.size();i++) {
			Identifiable ident = ls.get(i);
			//2 avec dessin
     	    tabTetes[i]=FabriqueIhm.dessinerPersonnage(ident);
		}
        
		//Afficher /ligne de 4
		String strTrombi = construireTrombi(tabTetes,4,ls.size());
		v.afficherChaine(strTrombi);
   }
    /**
     * M�thode charg�e d'afficher le trombi des personnages.
     * @param tabTetes String[][]: le tableu des t�tes
     * @param max int: le nombre par ligne
     * @return String
     */
    private String construireTrombi(String[][] tabTetes, int max,int lsSize) {
    	StringBuilder builder = new StringBuilder(Cview.TITRE_TROMBI);
    	builder.append(System.lineSeparator());
       
    	for(int c=0;c<7;c++) {
    		for(int p=0;p<tabTetes.length;p++) {
    			builder.append(String.format("%10s", tabTetes[p][c])).append(" | ");
    		}
    		builder.append(System.lineSeparator());
    	}
    	
    	for(int p=0;p<tabTetes.length;p++) {
			builder.append(String.format("%-10d", (p+1))).append(" | ");
		}
	
    	builder.append(System.lineSeparator());
        
    	return builder.toString();
    }


	/**
     * M�thode charg�e de r�aliser les traitements du sous menu PARTIE.
     * @param vue Ihm: saisie et affichage
     * @param chx int: le choix
     * @param ls List<Identifiable>: la liste des personnages
     * @return boolean: fin de la partie ? ou pas
     * @throws PartieException
     * @throws IhmException
     * @throws QuestionException 
     */
	private boolean traiterChoixSousMenuPartie(Ihm vue,int chx, List<Identifiable> ls) throws PartieException, IhmException, QuestionException {
		boolean retour = false;
    	
		switch(chx) {
		case Cview.CHOIX_QUITTER:
			break;
		case Cview.SMENU_CHX1_QUESTION:
			//Faire choisir typeQuestion
			Questionnable laQuestion=choisirTypeQuestion(vue); 
			
			//Poser la question
			boolean reponse = metier.poserquestion(laQuestion);
			
			//afficher r�ponse : OUI / NON
			if(reponse) {
				vue.afficherChaine(String.format(Cview.PATTERN_MSG_CRITERE_OK,
						                         FabriqueIhm.buildstrReponse(laQuestion)));
			}else {
				vue.afficherChaine(String.format(Cview.PATTERN_MSG_CRITERE_NOK,
						FabriqueIhm.buildstrReponse(laQuestion)));
			}
			break;
		case Cview.SMENU_CHX2_ELIMINER:
			//proposer les personnages � oublier
			int idxPerso = vue.saisirEntier("No de personnage � �liminer ?", 0, 13);
			supprimer(idxPerso,ls);
			vue.afficherChaine(Cview.MSG_ELIMINER_OK);
			break;
		case Cview.SMENU_CHX3_PROPOSER:
			//recuperer le personnage tir� par joueur IA
			//Identifiable perso = metier.getLaPartie().getPerso();
			String nomToFind =	metier.getNomATrouver().toUpperCase().trim();
			
			//Faire saisir un pr�nom
			String nom = vue.saisirChaine(Cview.INVITE_SAISIE_NOM).toUpperCase();
					
			// G ou perdu
			if (nomToFind.equals(nom)) {
				vue.afficherChaine(Cview.MSG_GAGNE);
			}else {
				vue.afficherChaine(String.format(Cview.PATTERN_MSG_PERDU,nomToFind));
			}
			retour = true; //fin de la parties
			break;
		}
		return retour;
	}
	

	/**
	 * M�thode charge r�aliser la saisie d'une question(Type et valeur si n�cessaire)
	 * @param vue2 Ihm: saisie et affichage
	 * @return Questionnable
	 * @throws IhmException 
	 * @throws QuestionException 
	 */
    private Questionnable choisirTypeQuestion(Ihm vue) throws IhmException, QuestionException {
		Questionnable newQuest = null;
    	//les questions:
    	// TypeAccessoire
    	// Carac: TypeQuestion et valeur
		int chx=0;
		vue.afficherChaine(OutilsChaine.buildStringMenuFromEnum(
		    		"SMENU saisie TypeQuestion",
		    		TypeQuestion.class));
		    
		chx = vue.saisirEntier("Choisir le type ?",
		    		               Cview.CHOIX_QUITTER,
		    		               TypeQuestion.values().length);
		if (chx != Cview.CHOIX_QUITTER) {
		  	newQuest= traiterChoixSaisieTypeQuestion(vue,chx);
		}
		    
		return newQuest;
	}

	private Questionnable traiterChoixSaisieTypeQuestion(Ihm vue2, int chx) throws QuestionException, IhmException {
	    Questionnable q= null;
		chx--;
	    
		TypeQuestion  tq= TypeQuestion.values()[chx];
		if (tq==TypeQuestion.ACCESSOIRE) {
			int chx2=0;
			// Question portant sur les accessoires ==> faire saisir  TypeAccessoire
			vue.afficherChaine(OutilsChaine.buildStringMenuFromEnum(
		    		"SMENU saisie TypeAccessoire",
		    		TypeAccessoire.class));
		    
		    chx2 = vue.saisirEntier("Choisir le type ?",
		    		               Cview.CHOIX_QUITTER,
		    		               TypeAccessoire.values().length);
		    
			if (chx2 != Cview.CHOIX_QUITTER) {
				chx2--;
				TypeAccessoire ta =  TypeAccessoire.values()[chx2];
				q = FabriqueMetier.creerQuestionAcc(ta);
			}
			
		}else {
			// question portant sur caract�ristiques => valeur
			String valeur =  vue2.saisirChaine("Saisir la valeur pour la caract�ristique ?");
			
			//TODO controler les valeurs saisies
			//       se servir de la classe Question et d'une EXCEPTION
		    
			q = FabriqueMetier.creerQuestionCarac(tq, valeur);
		}
		return q;
	}

	/**
     * M�thode charg�e de supprimer l'�l�ment dans la liste.
     * @param idxPerso int: indice choisi
     * @param ls List<Identifiable>: la liste des personnages
     */
	private void supprimer(int idxPerso, List<Identifiable> ls) {
		idxPerso--;
		if (idxPerso>=0 && idxPerso<ls.size()) {
				ls.remove(idxPerso);
		}
	}
	
}
