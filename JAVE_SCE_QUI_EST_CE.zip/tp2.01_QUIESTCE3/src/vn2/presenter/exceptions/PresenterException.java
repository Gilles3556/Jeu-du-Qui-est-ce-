package vn2.presenter.exceptions;

public class PresenterException extends Exception {

	public PresenterException(String msg){
		super(msg);
	}
}
