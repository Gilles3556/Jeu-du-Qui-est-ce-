package vn2.view;

import vn2.view.exceptions.IhmException;

public interface Ihm {

	public String saisirChaine(String invite);
	
	public int saisirEntier(String invite,int min, int max) throws IhmException;
	
	public double saisirDouble(String invite, double min, double max) throws IhmException;
	
	public void afficherChaine(String msg);

	public void afficherErreur(String message);
}
