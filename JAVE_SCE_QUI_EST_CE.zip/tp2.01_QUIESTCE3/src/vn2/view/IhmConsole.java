package vn2.view;

import java.util.Scanner;

import vn2.view.exceptions.IhmException;

public class IhmConsole implements Ihm {
	private Scanner  scan= new Scanner(System.in);

	
	@Override
	public String saisirChaine(String invite) {
		afficherChaine(invite);
		String str = scan.next();
		return str;
	}

	@Override
	public int saisirEntier(String invite, int min, int max) throws IhmException {
		int saisie=0;
		do {
			afficherChaine(invite);
			saisie = scan.nextInt();
			
			if(saisie<min || saisie>max) {
				throw new IhmException(Cview.ERR_MSG_NOMBRE_INCORRECT);
			}
		}while(saisie<min || saisie>max);
		return saisie;
	}

	@Override
	public double saisirDouble(String invite, double min, double max) throws IhmException {
		double saisie=0;
		do {
			afficherChaine(invite);
			saisie = scan.nextDouble();
			System.out.println("SAISIE="+saisie);
			if(saisie<min || saisie>max) {
				throw new IhmException(Cview.ERR_MSG_NOMBRE_INCORRECT);
			}
		}while(saisie<min || saisie>max);
		return saisie;
	}

	@Override
	public void afficherChaine(String msg) {
		System.out.println(msg);
	}

	@Override
	public void afficherErreur(String message) {
		System.err.println(message);
		
	}

}
