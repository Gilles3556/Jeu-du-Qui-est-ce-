package vn2.view;

public final class Cview {

	private Cview() {
	}
	
	public static final String TITRE_MENU_PRINCIPAL = "---MENU PRINCIPAL---";
	public final static String[] TAB_MENU_PRINCIPAL= {"initialiser",
			                                          "inscrire un joueur",
			                                          "lancer une partie",
			                                          "afficher trombi tous"
	                                                   };
	public final static int MENUP_CHX1_INIT=1;
	public final static int MENUP_CHX2_INSC=2;
	public final static int MENUP_CHX3_PARTIE=3;
	
	public static final String TITRE_SMENU_PARTIE = "---MENU UNE PARTIE---";
	public final static String[] TAB_SMENU_PARTIE= {
			"proposer une question",
			"�liminer personnage",
			"proposer le nom"
	};
	public final static int SMENU_CHX1_QUESTION=1;
	public final static int SMENU_CHX2_ELIMINER=2;
	public final static int SMENU_CHX3_PROPOSER=3;
	
	public static final int CHOIX_QUITTER = 0;

	public static final String INVITE_CHOIX = "votre choix ?";



	public static final String MSG_LISTE_CRITERE_VIDE = "Aucun Personnage avec ce crit�re !";
	public static final String MSG_PERSONNAGE_INCONNU = "Err: personnage inconnu";
	
	public static final String ERR_MSG_NOMBRE_INCORRECT = "ERR: nombre incorrect";
	public static final String MSG_ERR_PERSONNAGE_DEJA_EXISTANT = "Err: personnage d�j� pr�sent";
	public static final String MSG_ERR_PERSONNAGE_INEXISTANT = "ERR: Le personnage n'existe pas !";
	public static final String MSG_PERSONNAGE_VAUT_NULL = "EER: le personnage vaut null!";
	public static final String MSG_ERR_IHM_VAUT_NULL = "ERR: l'Ihm vaut null";
	
	public static final String INVITE_SAISIE_NOM= "Saisir le nom du personnage?";
	public static final Object STR_QUITTER = "0] QUITTER";

	public static final String TITRE_INSCRIPTION = "SAISIR INSCRIPTION";
	public static final String MSG_TRT_SUPPRIMER_OK = ">>suppresion OK";
    public static final String MSG_TRT_CREER_OK = ">>cr�ation OK";
    public static final String MSG_TRT_MODIFIER_OK = ">>modification OK";
    
    public static final String CHOIX1_OK = ">>choix 1: OK";

    public static final String CHOIX2_OK = ">>inscription OK";
	public static final String MSG_GAGNE = "BRAVO, vous avez gagn�!";
	public static final String PATTERN_MSG_PERDU = "Perdu ! vous auriez d� trouver %s";
	public static final String TITRE_LISTE = "la liste des personnages";
	public static final String MSG_ELIMINER_OK = ">>Elimination OK";
	public static final String MSG_CRITERE_OK = "OUI, le personnage poss�de le crit�re indiqu�";
	public static final String MSG_CRITERE_NOK = "NON, le personnage ne poss�de pas le crit�re indiqu�";
	public static final String PATTERN_MSG_CRITERE_OK = "OUI, le personnge poss�de %s";
	public static final String PATTERN_MSG_CRITERE_NOK = "NON, le personnge ne poss�de pas %s";
	public static final String TITRE_TROMBI = "---Trombinoscope des persos. ---";
	
	
	

}
