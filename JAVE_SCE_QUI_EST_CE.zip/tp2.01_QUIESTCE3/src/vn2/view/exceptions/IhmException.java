package vn2.view.exceptions;

public class IhmException extends Exception {

	public IhmException(String msg) {
		super(msg);
	}
}
