package vn2.view;

import vn2.model.entities.Identifiable;
import vn2.model.entities.Questionnable;
import vn2.model.references.TypeAccessoire;

public final  class FabriqueIhm {

	private FabriqueIhm() {	}
	
	/**
	 * Cr�ation de menu � partir de Cview.TAB_MENU_PRINCIPAL.
	 * @return String
	 */
	public static String creerMenu() {
		StringBuilder builder = new StringBuilder(Cview.TITRE_MENU_PRINCIPAL);
		builder.append(System.lineSeparator());
		
		for (int i = 0; i < Cview.TAB_MENU_PRINCIPAL.length; i++) {
			builder.append(String.format("-%d %10s",(i+1),Cview.TAB_MENU_PRINCIPAL[i]));
			builder.append(System.lineSeparator());
		}
		builder.append(" 0] quitter");
		builder.append(System.lineSeparator());
		
		return builder.toString();
	}
	public static Ihm creerImhConsole() {
		return new IhmConsole();
	}
	/**
	 * M�thode charg�e cr��er une r�ponse au format String.
	 * @param laQuestion questionnable: la question
	 * @return String
	 */
	public static String  buildstrReponse(Questionnable laQuestion) {
		String strReponse ="";
		if (laQuestion.getUnAccessoire()!=null) {
			strReponse = laQuestion.getUnAccessoire().name();
		}else {
			strReponse = laQuestion.getLeType().name()+" = "+laQuestion.getValeur();
		}
		return strReponse;
	}
	/**
	 * M�thode charg�e cr�er la repr�sentation du sous menu � partir du tableau.
	 * @return String
	 */
	public static String creerSmenuPartie() {
    	StringBuilder builder = new StringBuilder(Cview.TITRE_SMENU_PARTIE);
		builder.append(System.lineSeparator());
		
		for (int i = 0; i < Cview.TAB_SMENU_PARTIE.length; i++) {
			builder.append(String.format("-%d %15s", (i+1),Cview.TAB_SMENU_PARTIE[i]));
			builder.append(System.lineSeparator());
		}
		builder.append(Cview.STR_QUITTER);
		builder.append(System.lineSeparator());
		
		return builder.toString();
    }
	/**
	 * M�thode charg�e cr�er la repr�sentation du menu principal � partir du tableau.
	 * @return String
	 */
	public static String creerMenuPrincipal() {
		StringBuilder builder = new StringBuilder(Cview.TITRE_MENU_PRINCIPAL);
		builder.append(System.lineSeparator());
		
		for (int i = 0; i < Cview.TAB_MENU_PRINCIPAL.length; i++) {
			builder.append(String.format("-%d %15s", (i+1),Cview.TAB_MENU_PRINCIPAL[i]));
			builder.append(System.lineSeparator());
		}
		builder.append(Cview.STR_QUITTER);
		builder.append(System.lineSeparator());
		
		return builder.toString();
	}
	
	public static String[] dessinerPersonnage(Identifiable pid){
		String[] tabloTete= new String[7];
		
		//cheveux
		char c= pid.getCheveux().toLowerCase().charAt(0);
		tabloTete[0] = ".."+c+c+c+"..";
		
		//yeux
		char c2 = pid.getYeux().toLowerCase().charAt(0);
		boolean lunette = pid.getValeurAccessoire(TypeAccessoire.LUNETTE);
		tabloTete[1] = "./"+c2+(lunette?"=":" ")+c2+"\\.";
		
		//Oreille
		tabloTete[2]="[  -  ]";
		boolean boucle = pid.getValeurAccessoire(TypeAccessoire.BOUCLE_DOREILLE);
		if (boucle) {
			tabloTete[3]="!\\";
		}else {
			tabloTete[3]=".\\";
		}
		boolean moustache = pid.getValeurAccessoire(TypeAccessoire.MOUSTACHE);
		boolean barbe = pid.getValeurAccessoire(TypeAccessoire.BARBE);
		boolean cigare = pid.getValeurAccessoire(TypeAccessoire.CIGARE);
		if (cigare) {
			tabloTete[3]+=" ===.";
		}else {
			if (moustache || barbe) {
				tabloTete[3]+=""+c+c+c+"/.";
			}else {
				tabloTete[3]+="   /.";
			}
		}
		
		if (barbe) {
			tabloTete[4]=".."+c+c+c+"..";
		}else {
			tabloTete[4]="..\\ /..";
		}
		tabloTete[5]="...-...";
		
		tabloTete[6]= pid.getNom();
		return tabloTete;
		
	}
	
	public static String constuireTete(Identifiable pid) {
		String[] tab = dessinerPersonnage(pid);
		StringBuilder builder = new StringBuilder();
		for (String str : tab) {
			builder.append(str).append(System.lineSeparator());
		}
		return builder.toString();
	}
	
}
