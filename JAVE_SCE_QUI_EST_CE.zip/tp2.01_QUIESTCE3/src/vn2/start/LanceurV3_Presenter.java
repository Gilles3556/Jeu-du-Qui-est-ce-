package vn2.start;

import vn2.presenter.Presenter;
import vn2.view.FabriqueIhm;
import vn2.view.Ihm;

public class LanceurV3_Presenter {

	public static void main(String[] args) {
		Ihm vue = FabriqueIhm.creerImhConsole();
		Presenter pres =new Presenter(vue, "lespersonnages2.properties");

		pres.executer();
		
		
	}

}
